module.exports = {
    DB_NAME : "ecomm_db",
    DB_URL : "mongodb://127.0.0.1/ecomm_db" 

}